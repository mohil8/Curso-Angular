import { Prueba } from './prueba';

describe('Prueba', () => {
  it('should create an instance', () => {
    expect(new Prueba()).toBeTruthy();
  });
});
