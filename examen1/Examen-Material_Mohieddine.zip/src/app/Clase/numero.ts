export class Numero {
  indice!:number;
  n1!:number;
  n2!:number;
  n3!:number;
  n4!:number;
  n5!:number;
  n6!:number;

  constructor(indice:number,n1:number,n2:number,n3:number,n4:number,n5:number,n6:number){
    this.indice=indice;
    this.n1=n1;
    this.n2=n2;
    this.n3=n3;
    this.n4=n4;
    this.n5=n5;
    this.n6=n6;
  }
}
