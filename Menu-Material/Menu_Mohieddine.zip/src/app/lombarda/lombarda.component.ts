import { Component } from '@angular/core';

@Component({
  selector: 'app-lombarda',
  templateUrl: './lombarda.component.html',
  styleUrls: ['./lombarda.component.css']
})
export class LombardaComponent {

nombreFondo: any;
letras:string='012345678ABCDEF';

numero:number=this.letras.length;

renaudar() {



}

parar() {



}


}
